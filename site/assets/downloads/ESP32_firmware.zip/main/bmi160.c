#include "bmi160.h"

#include <stdint.h>
#include <string.h>
#include <stdio.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "driver/spi_master.h"

#include "esp_err.h"


// ============================================================
// SPI configuration
// ============================================================

#define BMI160_SPI_HOST        SPI2_HOST

// Free GPIO in your current OLED wiring.
#define BMI160_PIN_CS          5

#define BMI160_SPI_HZ          (1 * 1000 * 1000)


// ============================================================
// BMI160 registers
// ============================================================

#define BMI160_REG_CHIP_ID     0x00
#define BMI160_REG_PMU_STATUS  0x03

#define BMI160_REG_ACC_X_L     0x12

#define BMI160_REG_ACC_CONF    0x40
#define BMI160_REG_ACC_RANGE   0x41

#define BMI160_REG_CMD         0x7E

#define BMI160_CHIP_ID         0xD1

// Accelerometer normal mode command.
#define BMI160_CMD_ACC_NORMAL  0x11

// ±2 g range.
#define BMI160_ACC_RANGE_2G    0x03

// 100 Hz ODR, normal filtering.
// This is also the BMI160 reset value for ACC_CONF.
#define BMI160_ACC_CONF_100HZ  0x28

#define BMI160_READ_BIT        0x80
#define BMI160_WRITE_MASK      0x7F

#define BMI160_LSB_PER_G_2G    16384


static spi_device_handle_t bmi160_spi;


// ============================================================
// Low-level SPI
// ============================================================

static esp_err_t bmi160_read(
    uint8_t reg,
    uint8_t *data,
    size_t length
)
{
    if (data == NULL || length == 0) {
        return ESP_ERR_INVALID_ARG;
    }

    /*
     * BMI160 SPI read:
     *
     * byte 0:
     *     bit7 = 1 for READ
     *     bits6:0 = register address
     *
     * Following bytes clock out register data.
     *
     * rx[0] corresponds to the command phase and is ignored.
     */

    uint8_t tx[32] = {0};
    uint8_t rx[32] = {0};

    if ((length + 1) > sizeof(tx)) {
        return ESP_ERR_INVALID_SIZE;
    }

    tx[0] = reg | BMI160_READ_BIT;

    spi_transaction_t transaction = {
        .length = (length + 1) * 8,
        .tx_buffer = tx,
        .rx_buffer = rx,
    };

    esp_err_t err =
        spi_device_transmit(
            bmi160_spi,
            &transaction
        );

    if (err != ESP_OK) {
        return err;
    }

    memcpy(
        data,
        &rx[1],
        length
    );

    return ESP_OK;
}


static esp_err_t bmi160_read_u8(
    uint8_t reg,
    uint8_t *value
)
{
    return bmi160_read(
        reg,
        value,
        1
    );
}


static esp_err_t bmi160_write_u8(
    uint8_t reg,
    uint8_t value
)
{
    uint8_t tx[2] = {
        reg & BMI160_WRITE_MASK,
        value
    };

    spi_transaction_t transaction = {
        .length = sizeof(tx) * 8,
        .tx_buffer = tx,
    };

    esp_err_t err =
        spi_device_transmit(
            bmi160_spi,
            &transaction
        );

    /*
     * BMI160 requires an idle interval after writes.
     * 1 ms is intentionally conservative for this demo.
     */
    vTaskDelay(pdMS_TO_TICKS(1));

    return err;
}


// ============================================================
// Public API
// ============================================================

esp_err_t bmi160_init(void)
{
    /*
     * oled_init() initializes SPI2_HOST first.
     *
     * Here we simply add BMI160 as the second device
     * on the same SPI bus.
     */
    spi_device_interface_config_t device_config = {
        .clock_speed_hz = BMI160_SPI_HZ,
        .mode = 0,
        .spics_io_num = BMI160_PIN_CS,
        .queue_size = 1,
    };

    esp_err_t err =
        spi_bus_add_device(
            BMI160_SPI_HOST,
            &device_config,
            &bmi160_spi
        );

    if (err != ESP_OK) {
        return err;
    }

    /*
     * BMI160 powers up in I2C mode.
     *
     * Bosch recommends performing a SPI read at 0x7F
     * first. The CS rising edge at the end of this
     * transaction selects SPI operation.
     */
    uint8_t dummy = 0;

    bmi160_read_u8(
        0x7F,
        &dummy
    );

    vTaskDelay(pdMS_TO_TICKS(1));

    // --------------------------------------------------------
    // Confirm device identity
    // --------------------------------------------------------

    uint8_t chip_id = 0;

    err = bmi160_read_u8(
        BMI160_REG_CHIP_ID,
        &chip_id
    );

    if (err != ESP_OK) {
        return err;
    }

    printf(
        "BMI160 CHIP_ID = 0x%02X\n",
        chip_id
    );

    if (chip_id != BMI160_CHIP_ID) {
        printf(
            "ERROR: expected BMI160 CHIP_ID 0x%02X\n",
            BMI160_CHIP_ID
        );

        return ESP_ERR_NOT_FOUND;
    }

    // --------------------------------------------------------
    // Configure accelerometer
    // --------------------------------------------------------

    err = bmi160_write_u8(
        BMI160_REG_ACC_CONF,
        BMI160_ACC_CONF_100HZ
    );

    if (err != ESP_OK) {
        return err;
    }

    err = bmi160_write_u8(
        BMI160_REG_ACC_RANGE,
        BMI160_ACC_RANGE_2G
    );

    if (err != ESP_OK) {
        return err;
    }

    /*
     * Move accelerometer from suspend to normal mode.
     */
    err = bmi160_write_u8(
        BMI160_REG_CMD,
        BMI160_CMD_ACC_NORMAL
    );

    if (err != ESP_OK) {
        return err;
    }

    /*
     * Bosch specifies roughly 3.2 ms typical startup
     * for accelerometer normal mode.
     *
     * Give it plenty of margin for this demo.
     */
    vTaskDelay(pdMS_TO_TICKS(10));

    // --------------------------------------------------------
    // Confirm power state
    // --------------------------------------------------------

    uint8_t pmu_status = 0;

    err = bmi160_read_u8(
        BMI160_REG_PMU_STATUS,
        &pmu_status
    );

    if (err != ESP_OK) {
        return err;
    }

    printf(
        "BMI160 PMU_STATUS = 0x%02X\n",
        pmu_status
    );

    printf("BMI160 initialized\n");

    return ESP_OK;
}


esp_err_t bmi160_read_accel(
    bmi160_accel_t *accel
)
{
    if (accel == NULL) {
        return ESP_ERR_INVALID_ARG;
    }

    /*
     * Burst read:
     *
     * 0x12 ACC_X_L
     * 0x13 ACC_X_H
     * 0x14 ACC_Y_L
     * 0x15 ACC_Y_H
     * 0x16 ACC_Z_L
     * 0x17 ACC_Z_H
     */
    uint8_t raw[6];

    esp_err_t err =
        bmi160_read(
            BMI160_REG_ACC_X_L,
            raw,
            sizeof(raw)
        );

    if (err != ESP_OK) {
        return err;
    }

    accel->raw_x =
        (int16_t)(
            ((uint16_t)raw[1] << 8) |
            raw[0]
        );

    accel->raw_y =
        (int16_t)(
            ((uint16_t)raw[3] << 8) |
            raw[2]
        );

    accel->raw_z =
        (int16_t)(
            ((uint16_t)raw[5] << 8) |
            raw[4]
        );

    /*
     * ±2 g:
     *
     * 16384 LSB/g nominal.
     *
     * Convert to milli-g so we don't need float.
     */
    accel->x_mg =
        ((int32_t)accel->raw_x * 1000)
        / BMI160_LSB_PER_G_2G;

    accel->y_mg =
        ((int32_t)accel->raw_y * 1000)
        / BMI160_LSB_PER_G_2G;

    accel->z_mg =
        ((int32_t)accel->raw_z * 1000)
        / BMI160_LSB_PER_G_2G;

    return ESP_OK;
}