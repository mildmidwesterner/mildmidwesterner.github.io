#pragma once

#include <stdint.h>
#include "esp_err.h"


typedef struct
{
    int16_t raw_x;
    int16_t raw_y;
    int16_t raw_z;

    int32_t x_mg;
    int32_t y_mg;
    int32_t z_mg;
} bmi160_accel_t;


esp_err_t bmi160_init(void);

esp_err_t bmi160_read_accel(
    bmi160_accel_t *accel
);