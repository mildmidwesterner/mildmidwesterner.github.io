#include <stdio.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "esp_err.h"

#include "oled.h"
#include "bmi160.h"


void app_main(void)
{
    /*
     * oled_init() initializes the shared SPI2 bus
     * and attaches the OLED.
     */
    oled_init();

    /*
     * BMI160 is then attached as the second device
     * on that same SPI bus.
     */
    ESP_ERROR_CHECK(
        bmi160_init()
    );

    bmi160_accel_t accel;

    while (1)
    {
        esp_err_t err =
            bmi160_read_accel(
                &accel
            );

        if (err == ESP_OK)
        {
            printf(
                "ACC X=%ld mg  Y=%ld mg  Z=%ld mg\n",
                (long)accel.x_mg,
                (long)accel.y_mg,
                (long)accel.z_mg
            );

            oled_draw_accel(
                accel.x_mg,
                accel.y_mg,
                accel.z_mg
            );
        }
        else
        {
            printf(
                "BMI160 read failed: %s\n",
                esp_err_to_name(err)
            );
        }

        /*
         * Update display at 10 Hz.
         */
        vTaskDelay(
            pdMS_TO_TICKS(100)
        );
    }
}