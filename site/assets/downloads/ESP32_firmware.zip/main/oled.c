#include "oled.h"
#include "font.h"

#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <stdio.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "driver/gpio.h"
#include "driver/spi_master.h"

#include "esp_err.h"


#define OLED_PIN_SCLK   7 //D8
#define OLED_PIN_MOSI   9 //D10
#define OLED_PIN_MISO   8
#define OLED_PIN_CS     4 //D3
#define OLED_PIN_DC     3 //D2
#define OLED_PIN_RESET  2 //D1

#define OLED_BUFFER_SIZE (OLED_WIDTH * OLED_HEIGHT / 8)


static spi_device_handle_t oled_spi;
static uint8_t framebuffer[OLED_BUFFER_SIZE];

static void oled_clear(void);
static void oled_update(void);


/*
 * Send one SPI transaction.
 *
 * dc_level = 0: bytes are commands
 * dc_level = 1: bytes are display data
 */
static void oled_send(const uint8_t *data, size_t length, int dc_level)
{
    gpio_set_level(OLED_PIN_DC, dc_level);

    spi_transaction_t transaction = {
        .length = length * 8,
        .tx_buffer = data,
    };

    ESP_ERROR_CHECK(spi_device_transmit(oled_spi, &transaction));
}


static void oled_send_commands(const uint8_t *commands, size_t length)
{
    oled_send(commands, length, 0);
}



static void oled_send_data(const uint8_t *data, size_t length)
{
    oled_send(data, length, 1);
}


static void oled_hardware_reset(void)
{
    gpio_set_level(OLED_PIN_RESET, 0);
    vTaskDelay(pdMS_TO_TICKS(20));

    gpio_set_level(OLED_PIN_RESET, 1);
    vTaskDelay(pdMS_TO_TICKS(20));
}


static void oled_initialize_controller(void)
{
    /*
     * Standard initialization sequence for a
     * 128 × 64 SSD1306 OLED.
     */
    static const uint8_t initialization_commands[] = {
        0xAE,       // Display OFF

        0xD5, 0x80, // Display clock
        0xA8, 0x3F, // Multiplex ratio: 64 rows
        0xD3, 0x00, // Display offset
        0x40,       // Start line 0

        0x8D, 0x14, // Enable internal charge pump

        0x20, 0x00, // Horizontal addressing mode

        0xA1,       // Segment remap
        0xC8,       // COM scan direction

        0xDA, 0x12, // COM pin configuration
        0x81, 0x7F, // Contrast
        0xD9, 0xF1, // Pre-charge period
        0xDB, 0x40, // VCOMH level

        0xA4,       // Display RAM contents
        0xA6,       // Normal display
        0x2E,       // Disable scrolling

        0xAF        // Display ON
    };

    oled_hardware_reset();

    oled_send_commands(
        initialization_commands,
        sizeof(initialization_commands)
    );
}


static void oled_set_full_screen_address(void)
{
    static const uint8_t address_commands[] = {
        0x21, 0x00, 0x7F, // Columns 0 through 127
        0x22, 0x00, 0x07  // Pages 0 through 7
    };

    oled_send_commands(address_commands, sizeof(address_commands));
}

static void oled_set_pixel(int x, int y, bool on)
{
    if (x < 0 || x >= OLED_WIDTH ||
        y < 0 || y >= OLED_HEIGHT) {
        return;
    }

    int page = y / 8;
    int bit = y % 8;
    int index = page * OLED_WIDTH + x;

    uint8_t mask = 1U << bit;

    if (on) {
        framebuffer[index] |= mask;
    } else {
        framebuffer[index] &= ~mask;
    }
    
}

static int font_index_from_char(char character)
{
    if (character >= '0' && character <= '9') {
        return character - '0';
    }

    if (character == ':') {
        return 10;
    }

    if (character == '.') {
        return 11;
    }

    if (character == ' ') {
        return 12;
    }

    if (character == '-') {
        return 13;
    }

    if (character == 'X') {
        return 14;
    }

    if (character == 'Y') {
        return 15;
    }

    if (character == 'Z') {
        return 16;
    }

    return 12;
}

static void oled_draw_char(
    int x,
    int y,
    char character,
    int scale
)
{
    int font_index = font_index_from_char(character);

    for (int row = 0; row < FONT_HEIGHT; row++) {
        uint8_t row_bits = font_digits[font_index][row];

        for (int column = 0; column < FONT_WIDTH; column++) {
            bool pixel_on =
                row_bits & (1U << (FONT_WIDTH - 1 - column));

            for (int offset_y = 0; offset_y < scale; offset_y++) {
                for (int offset_x = 0; offset_x < scale; offset_x++) {
                    oled_set_pixel(
                        x + column * scale + offset_x,
                        y + row * scale + offset_y,
                        pixel_on
                    );
                }
            }
        }
    }
}

static void oled_draw_string(
    int x,
    int y,
    const char *text,
    int scale
)
{
    int cursor_x = x;
    int character_spacing = scale;

    while (*text != '\0') {
        oled_draw_char(cursor_x, y, *text, scale);

        cursor_x += FONT_WIDTH * scale + character_spacing;
        text++;
    }
}

static void oled_spi_initialize(void)
{
    gpio_config_t output_config = {
        .pin_bit_mask =
            (1ULL << OLED_PIN_DC) |
            (1ULL << OLED_PIN_RESET),
        .mode = GPIO_MODE_OUTPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE
    };

    ESP_ERROR_CHECK(gpio_config(&output_config));

    spi_bus_config_t bus_config = {
        .mosi_io_num = OLED_PIN_MOSI,
        .miso_io_num = OLED_PIN_MISO,
        .sclk_io_num = OLED_PIN_SCLK,
        .quadwp_io_num = -1,
        .quadhd_io_num = -1,
        .max_transfer_sz = OLED_BUFFER_SIZE
    };

    ESP_ERROR_CHECK(
        spi_bus_initialize(
            SPI2_HOST,
            &bus_config,
            SPI_DMA_CH_AUTO
        )
    );

    spi_device_interface_config_t device_config = {
        .clock_speed_hz = 1 * 1000 * 1000,
        .mode = 0,
        .spics_io_num = OLED_PIN_CS,
        .queue_size = 1
    };

    ESP_ERROR_CHECK(
        spi_bus_add_device(
            SPI2_HOST,
            &device_config,
            &oled_spi
        )
    );
}

static void format_accel_axis(
    char *buffer,
    size_t buffer_size,
    char axis,
    int32_t mg
)
{
    bool negative = mg < 0;

    int32_t magnitude =
        negative ? -mg : mg;

    int32_t whole =
        magnitude / 1000;

    int32_t fraction =
        magnitude % 1000;

    if (negative) {
        snprintf(
            buffer,
            buffer_size,
            "%c:-%ld.%03ld",
            axis,
            (long)whole,
            (long)fraction
        );
    }
    else {
        snprintf(
            buffer,
            buffer_size,
            "%c:%ld.%03ld",
            axis,
            (long)whole,
            (long)fraction
        );
    }
}


void oled_draw_accel(
    int32_t x_mg,
    int32_t y_mg,
    int32_t z_mg
)
{
    char x_text[20];
    char y_text[20];
    char z_text[20];

    format_accel_axis(
        x_text,
        sizeof(x_text),
        'X',
        x_mg
    );

    format_accel_axis(
        y_text,
        sizeof(y_text),
        'Y',
        y_mg
    );

    format_accel_axis(
        z_text,
        sizeof(z_text),
        'Z',
        z_mg
    );

    oled_clear();

    /*
     * Scale 1 gives enough vertical space
     * for all three axes.
     */
    oled_draw_string(
        5,
        5,
        x_text,
        1
    );

    oled_draw_string(
        5,
        25,
        y_text,
        1
    );

    oled_draw_string(
        5,
        45,
        z_text,
        1
    );

    oled_update();
}


static void oled_clear(void)
{
    memset(framebuffer, 0, sizeof(framebuffer));
}

static void oled_update(void)
{
    oled_set_full_screen_address();
    oled_send_data(framebuffer, sizeof(framebuffer));
}

void oled_init(void)
{
    oled_spi_initialize();
    oled_initialize_controller();

    oled_clear();
    oled_update();
}
