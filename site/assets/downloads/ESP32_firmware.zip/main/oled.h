#pragma once

#include <stdint.h>

#define OLED_WIDTH  128
#define OLED_HEIGHT 64

void oled_init(void);

void oled_draw_accel(
    int32_t x_mg,
    int32_t y_mg,
    int32_t z_mg
);
