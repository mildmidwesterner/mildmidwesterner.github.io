"""Top-level HIL device API."""

from __future__ import annotations

import time
from dataclasses import dataclass

from .protocol import (
    ERROR_BUSY,
    ERROR_NAMES,
    PACKET_TYPE_ACK,
    PACKET_TYPE_CLEAR_ERRORS,
    PACKET_TYPE_ERROR,
    PACKET_TYPE_GET_STATUS,
    PACKET_TYPE_GET_TIMESTAMP,
    PACKET_TYPE_PING,
    PACKET_TYPE_PING_RESP,
    PACKET_TYPE_STATUS_RESP,
    PACKET_TYPE_TIMESTAMP_RESP,
    Packet,
)
from .transport import SerialTransport
from .timestamp import Timestamp


class ProtocolError(RuntimeError):
    pass


class FPGAError(ProtocolError):
    def __init__(self, code: int, command: int) -> None:
        self.code = code
        self.command = command
        name = ERROR_NAMES.get(code, "unknown FPGA error")
        super().__init__(f"FPGA error 0x{code:02X} ({name}) for command 0x{command:02X}")


@dataclass(frozen=True)
class Status:
    raw: int

    @property
    def uart_framing_error(self) -> bool: return bool(self.raw & (1 << 0))
    @property
    def uart_overrun_error(self) -> bool: return bool(self.raw & (1 << 1))
    @property
    def packet_rx_crc_error(self) -> bool: return bool(self.raw & (1 << 2))
    @property
    def packet_rx_length_error(self) -> bool: return bool(self.raw & (1 << 3))
    @property
    def packet_tx_length_error(self) -> bool: return bool(self.raw & (1 << 4))
    @property
    def unsupported_command(self) -> bool: return bool(self.raw & (1 << 5))
    @property
    def invalid_command_length(self) -> bool: return bool(self.raw & (1 << 6))
    @property
    def spi_command_decode_error(self) -> bool: return bool(self.raw & (1 << 10))
    @property
    def spi_capture_overflow(self) -> bool: return bool(self.raw & (1 << 11))
    @property
    def spi_enable_requested(self) -> bool: return bool(self.raw & (1 << 12))
    @property
    def spi_armed(self) -> bool: return bool(self.raw & (1 << 13))
    @property
    def spi_cs_low(self) -> bool: return bool(self.raw & (1 << 14))
    @property
    def spi_shadow_ready(self) -> bool: return bool(self.raw & (1 << 15))


class HIL:
    ProtocolError = ProtocolError

    def __init__(
        self,
        port: str,
        baudrate: int = 115200,
        *,
        timeout: float = 2.0,
    ) -> None:
        self.transport = SerialTransport(port, baudrate, timeout=timeout)
        self.timeout = float(timeout)
        self._seq = 0

        # Imported lazily to avoid circular import at module load.
        from .spi import SPI
        self.spi = SPI(self)

    def open(self) -> "HIL":
        self.transport.open()
        return self

    def close(self) -> None:
        self.transport.close()

    def __enter__(self) -> "HIL":
        return self.open()

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def ping(self) -> bool:
        self._command(PACKET_TYPE_PING, b"", expected_type=PACKET_TYPE_PING_RESP)
        return True

    def get_status(self) -> Status:
        packet = self._command(
            PACKET_TYPE_GET_STATUS,
            b"",
            expected_type=PACKET_TYPE_STATUS_RESP,
        )
        if len(packet.payload) != 2:
            raise ProtocolError(f"status response length is {len(packet.payload)}, expected 2")
        return Status(int.from_bytes(packet.payload, "little"))

    def clear_errors(self) -> None:
        self._command(PACKET_TYPE_CLEAR_ERRORS, b"", expected_type=PACKET_TYPE_ACK)

    def get_timestamp(self) -> Timestamp:
        packet = self._command(
            PACKET_TYPE_GET_TIMESTAMP,
            b"",
            expected_type=PACKET_TYPE_TIMESTAMP_RESP,
        )
        if len(packet.payload) != 6:
            raise ProtocolError(
                f"timestamp response length is {len(packet.payload)}, expected 6"
            )
        return Timestamp(int.from_bytes(packet.payload, "little"))

    def _command(
        self,
        command: int,
        payload: bytes,
        *,
        expected_type: int,
        retry_busy: bool = False,
    ) -> Packet:
        deadline = time.monotonic() + self.timeout

        while True:
            seq = self._next_seq()
            self.transport.write_packet(command, seq, payload)

            while True:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise ProtocolError(
                        f"timed out waiting for response to command "
                        f"0x{command:02X}"
                    )

                packet = self.transport.read_packet(timeout=remaining)
                if packet.seq != seq:
                    # Current RTL does not emit unsolicited packets. Ignore
                    # stale sequence IDs left in the serial receive stream.
                    continue

                if packet.type == PACKET_TYPE_ERROR:
                    code = packet.payload[0] if packet.payload else 0
                    if retry_busy and code == ERROR_BUSY:
                        # Operations that require a physical SPI transaction
                        # boundary can temporarily report BUSY. Retry with a
                        # fresh sequence number until the command deadline.
                        time.sleep(0.001)
                        break
                    raise FPGAError(code, command)

                if packet.type != expected_type:
                    raise ProtocolError(
                        f"unexpected response type 0x{packet.type:02X} to command "
                        f"0x{command:02X}; expected 0x{expected_type:02X}"
                    )

                return packet

    def _next_seq(self) -> int:
        seq = self._seq
        self._seq = (self._seq + 1) & 0xFF
        return seq
