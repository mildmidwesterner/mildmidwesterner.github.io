"""Wire protocol constants and packet helpers for the current FPGA RTL."""

from __future__ import annotations

from dataclasses import dataclass

SYNC0 = 0xA5
SYNC1 = 0x5A
MAX_PAYLOAD_BYTES = 24

# Host -> FPGA: system
PACKET_TYPE_PING = 0x01
PACKET_TYPE_GET_STATUS = 0x02
PACKET_TYPE_CLEAR_ERRORS = 0x03
PACKET_TYPE_GET_TIMESTAMP = 0x04

# Host -> FPGA: SPI
CMD_SPI_CONFIG = 0x20
CMD_SPI_ENABLE = 0x21
CMD_SPI_REG_WRITE = 0x22
CMD_SPI_REG_READ = 0x23
CMD_SPI_REG_LOAD_BLOCK = 0x28
SPI_REG_LOAD_MAX_BYTES = 23

CMD_SPI_CAPTURE_CONFIG = 0x35
CMD_SPI_CAPTURE_START = 0x36
CMD_SPI_CAPTURE_STOP = 0x37
CMD_SPI_CAPTURE_CLEAR = 0x38
CMD_SPI_CAPTURE_STATUS = 0x39
CMD_SPI_CAPTURE_READ = 0x3A
CMD_SPI_REG_COMMIT = 0x3C

# FPGA -> host
PACKET_TYPE_PING_RESP = 0x81
PACKET_TYPE_STATUS_RESP = 0x82
PACKET_TYPE_ACK = 0x83
PACKET_TYPE_TIMESTAMP_RESP = 0x84
PACKET_TYPE_SPI_REG_READ_RESP = 0x85
PACKET_TYPE_SPI_CAPTURE_STATUS_RESP = 0x86
PACKET_TYPE_SPI_CAPTURE_READ_RESP = 0x87
PACKET_TYPE_ERROR = 0xE0

# Errors
ERROR_UNSUPPORTED_COMMAND = 0x01
ERROR_INVALID_LENGTH = 0x02
ERROR_INVALID_PARAMETER = 0x03
ERROR_BUSY = 0x04

ERROR_NAMES = {
    ERROR_UNSUPPORTED_COMMAND: "unsupported command",
    ERROR_INVALID_LENGTH: "invalid length",
    ERROR_INVALID_PARAMETER: "invalid parameter",
    ERROR_BUSY: "busy",
}


@dataclass(frozen=True)
class Packet:
    type: int
    seq: int
    payload: bytes = b""

    @property
    def length(self) -> int:
        return len(self.payload)


def crc16_ccitt_false(data: bytes, init: int = 0xFFFF) -> int:
    crc = init & 0xFFFF
    for byte in data:
        crc ^= byte << 8
        for _ in range(8):
            if crc & 0x8000:
                crc = ((crc << 1) ^ 0x1021) & 0xFFFF
            else:
                crc = (crc << 1) & 0xFFFF
    return crc


def encode_packet(packet_type: int, seq: int, payload: bytes = b"") -> bytes:
    payload = bytes(payload)
    if len(payload) > MAX_PAYLOAD_BYTES:
        raise ValueError(f"payload too long: {len(payload)} > {MAX_PAYLOAD_BYTES}")

    body = bytes((packet_type & 0xFF, seq & 0xFF, len(payload))) + payload
    crc = crc16_ccitt_false(body)
    return bytes((SYNC0, SYNC1)) + body + bytes((crc & 0xFF, (crc >> 8) & 0xFF))
