"""Declarative SPI register-device description."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable, Iterator


def _u8(name: str, value: int) -> int:
    value = int(value)
    if not 0 <= value <= 0xFF:
        raise ValueError(f"{name} must be 0..255")
    return value


@dataclass
class RegisterDevice:
    """Description + 256-byte initial register image for an SPI peripheral."""

    mode: int = 0
    default_miso: int = 0x00

    read_mask: int = 0x80
    read_value: int = 0x80

    write_mask: int = 0x80
    write_value: int = 0x00

    address_mask: int = 0x7F
    address_shift: int = 0

    auto_increment_mask: int = 0x00
    auto_increment_value: int = 0x00

    response_delay_bytes: int = 0
    fill: int = 0x00

    _image: bytearray = field(init=False, repr=False)

    def __post_init__(self) -> None:
        if not 0 <= int(self.mode) <= 3:
            raise ValueError("SPI mode must be 0, 1, 2, or 3")
        if not 0 <= int(self.address_shift) <= 7:
            raise ValueError("address_shift must be 0..7")

        for name in (
            "default_miso",
            "read_mask",
            "read_value",
            "write_mask",
            "write_value",
            "address_mask",
            "auto_increment_mask",
            "auto_increment_value",
            "response_delay_bytes",
            "fill",
        ):
            setattr(self, name, _u8(name, getattr(self, name)))

        if self.read_value & ~self.read_mask:
            raise ValueError("read_value contains bits outside read_mask")
        if self.write_value & ~self.write_mask:
            raise ValueError("write_value contains bits outside write_mask")
        if self.auto_increment_mask and (
            self.auto_increment_value & ~self.auto_increment_mask
        ):
            raise ValueError(
                "auto_increment_value contains bits outside auto_increment_mask"
            )

        self._image = bytearray([self.fill] * 256)

    def __getitem__(self, address: int) -> int:
        return self._image[self._address(address)]

    def __setitem__(self, address: int, value: int) -> None:
        self._image[self._address(address)] = _u8("register value", value)

    def load(self, data: Iterable[int], *, start: int = 0) -> None:
        start = self._address(start)
        values = bytes(_u8("register value", x) for x in data)
        if start + len(values) > 256:
            raise ValueError("register load extends past address 0xFF")
        self._image[start : start + len(values)] = values

    def image(self) -> bytes:
        return bytes(self._image)

    def items(self) -> Iterator[tuple[int, int]]:
        return iter(enumerate(self._image))

    @staticmethod
    def _address(address: int) -> int:
        address = int(address)
        if not 0 <= address <= 0xFF:
            raise ValueError("register address must be 0..255")
        return address
