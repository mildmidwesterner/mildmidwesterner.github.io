"""High-level SPI emulator API for the current register/capture RTL."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, TYPE_CHECKING

from .protocol import (
    CMD_SPI_CAPTURE_CLEAR,
    CMD_SPI_CAPTURE_CONFIG,
    CMD_SPI_CAPTURE_READ,
    CMD_SPI_CAPTURE_START,
    CMD_SPI_CAPTURE_STATUS,
    CMD_SPI_CAPTURE_STOP,
    CMD_SPI_CONFIG,
    CMD_SPI_ENABLE,
    CMD_SPI_REG_COMMIT,
    CMD_SPI_REG_LOAD_BLOCK,
    CMD_SPI_REG_READ,
    CMD_SPI_REG_WRITE,
    PACKET_TYPE_ACK,
    PACKET_TYPE_SPI_CAPTURE_READ_RESP,
    PACKET_TYPE_SPI_CAPTURE_STATUS_RESP,
    PACKET_TYPE_SPI_REG_READ_RESP,
    SPI_REG_LOAD_MAX_BYTES,
)
from .register_device import RegisterDevice
from .timestamp import Timestamp

if TYPE_CHECKING:
    from .device import HIL


def _u8(name: str, value: int) -> int:
    value = int(value)
    if not 0 <= value <= 0xFF:
        raise ValueError(f"{name} must be 0..255")
    return value


@dataclass(frozen=True)
class CaptureStatus:
    active: bool
    full: bool
    empty: bool
    loss_or_overflow: bool
    count: int
    depth: int
    armed: bool = False
    triggered: bool = False
    done: bool = False
    transaction_count: int = 0
    byte_count: int = 0


@dataclass(frozen=True)
class CaptureRecord:
    index: int
    event_type: int
    timestamp: Timestamp
    mosi: int
    miso: int
    transaction_lost: bool

    @property
    def type_name(self) -> str:
        return {0: "start", 1: "byte", 2: "end"}.get(self.event_type, "unknown")


class SPI:
    def __init__(self, dev: "HIL") -> None:
        self._dev = dev
        self._atomic_windows: list[tuple[int, int]] = []

    # ------------------------------------------------------------------
    # Configuration / enable
    # ------------------------------------------------------------------

    def configure(
        self,
        *,
        mode: int = 0,
        default_miso: int = 0x00,
        read_mask: int = 0x80,
        read_value: int = 0x80,
        write_mask: int = 0x80,
        write_value: int = 0x00,
        address_mask: int = 0x7F,
        address_shift: int = 0,
        auto_increment_mask: int = 0x00,
        auto_increment_value: int = 0x00,
        response_delay_bytes: int = 0,
    ) -> None:
        if not 0 <= int(mode) <= 3:
            raise ValueError("mode must be 0..3")
        if not 0 <= int(address_shift) <= 7:
            raise ValueError("address_shift must be 0..7")

        read_mask = _u8("read_mask", read_mask)
        read_value = _u8("read_value", read_value)
        write_mask = _u8("write_mask", write_mask)
        write_value = _u8("write_value", write_value)
        auto_increment_mask = _u8("auto_increment_mask", auto_increment_mask)
        auto_increment_value = _u8("auto_increment_value", auto_increment_value)

        if read_value & ~read_mask:
            raise ValueError("read_value contains bits outside read_mask")
        if write_value & ~write_mask:
            raise ValueError("write_value contains bits outside write_mask")
        if auto_increment_mask and auto_increment_value & ~auto_increment_mask:
            raise ValueError(
                "auto_increment_value contains bits outside auto_increment_mask"
            )

        payload = bytes(
            (
                int(mode),
                _u8("default_miso", default_miso),
                read_mask,
                read_value,
                write_mask,
                write_value,
                _u8("address_mask", address_mask),
                int(address_shift),
                auto_increment_mask,
                auto_increment_value,
                _u8("response_delay_bytes", response_delay_bytes),
            )
        )
        self._dev._command(
            CMD_SPI_CONFIG, payload, expected_type=PACKET_TYPE_ACK, retry_busy=True
        )

    def enable(self, enabled: bool = True) -> None:
        """Request SPI operation; arming waits for a safe CS-high boundary."""
        self._dev._command(
            CMD_SPI_ENABLE,
            bytes((1 if enabled else 0,)),
            expected_type=PACKET_TYPE_ACK,
        )

    def disable(self) -> None:
        self.enable(False)

    # ------------------------------------------------------------------
    # Register staging / commit
    # ------------------------------------------------------------------

    def stage_register(self, address: int, value: int) -> None:
        address = _u8("address", address)
        value = _u8("value", value)
        self._dev._command(
            CMD_SPI_REG_WRITE,
            bytes((address, value)),
            expected_type=PACKET_TYPE_ACK,
        )

    def stage_block(self, start: int, data: Iterable[int]) -> None:
        start = _u8("start", start)
        values = bytes(_u8("register value", x) for x in data)
        if not values:
            raise ValueError("data must contain at least one byte")
        if start + len(values) > 256:
            raise ValueError("register block extends past address 0xFF")

        offset = 0
        while offset < len(values):
            chunk = values[offset : offset + SPI_REG_LOAD_MAX_BYTES]
            addr = start + offset
            self._dev._command(
                CMD_SPI_REG_LOAD_BLOCK,
                bytes((addr,)) + chunk,
                expected_type=PACKET_TYPE_ACK,
            )
            offset += len(chunk)

    def commit(self, *, wait: bool = True) -> None:
        """Atomically switch the staged register bank into service.

        If an SPI transaction is active, the RTL queues the switch for the next
        CS-idle boundary. The ACK can precede the full-bank timing-shadow
        repair. With wait=True, a canonical read is used as a completion
        barrier because the RTL holds it until the register subsystem is READY.
        """
        self._dev._command(
            CMD_SPI_REG_COMMIT, b"", expected_type=PACKET_TYPE_ACK
        )
        if wait:
            self.read_register(0x00)

    def read_register(self, address: int) -> int:
        address = _u8("address", address)
        packet = self._dev._command(
            CMD_SPI_REG_READ,
            bytes((address,)),
            expected_type=PACKET_TYPE_SPI_REG_READ_RESP,
        )
        if len(packet.payload) != 2:
            raise self._dev.ProtocolError(
                f"SPI register read returned {len(packet.payload)} bytes, expected 2"
            )
        returned_addr, value = packet.payload
        if returned_addr != address:
            raise self._dev.ProtocolError(
                f"SPI register read address mismatch: requested 0x{address:02X}, "
                f"got 0x{returned_addr:02X}"
            )
        return value

    def write_register(self, address: int, value: int) -> None:
        self.stage_register(address, value)
        self.commit()

    def write_block(self, start: int, data: Iterable[int]) -> None:
        self.stage_block(start, data)
        self.commit()

    def update_atomic(self, start: int, data: Iterable[int]) -> None:
        """Stage an entire update, then expose it with one bank commit."""
        start = _u8("start", start)
        values = bytes(_u8("register value", x) for x in data)
        if not values:
            raise ValueError("atomic update must contain at least one byte")
        if start + len(values) > 256:
            raise ValueError("atomic update extends past address 0xFF")
        self._validate_atomic_window(start, len(values))
        self.stage_block(start, values)
        self.commit()

    def configure_atomic_window(self, start: int, length: int) -> None:
        """Declare a host-side atomic region.

        Current RTL does not require a separate FPGA atomic-window command.
        Writes are staged in the inactive register bank and SPI_REG_COMMIT
        performs the atomic switch.  This method keeps the convenient API used
        by device demos and validates later update_atomic() calls.
        """
        start = _u8("start", start)
        length = int(length)
        if not 1 <= length <= 256 - start:
            raise ValueError("atomic window must fit within 0x00..0xFF")
        self._atomic_windows.append((start, length))

    # ------------------------------------------------------------------
    # Device convenience
    # ------------------------------------------------------------------

    def emulate_registers(self, model: RegisterDevice, *, enable: bool = True) -> None:
        if not isinstance(model, RegisterDevice):
            raise TypeError("model must be a RegisterDevice")

        # Staging remains legal while SPI is live. CONFIG waits for physical
        # CS-idle, and COMMIT queues its atomic switch at the next idle boundary.
        self.configure(
            mode=model.mode,
            default_miso=model.default_miso,
            read_mask=model.read_mask,
            read_value=model.read_value,
            write_mask=model.write_mask,
            write_value=model.write_value,
            address_mask=model.address_mask,
            address_shift=model.address_shift,
            auto_increment_mask=model.auto_increment_mask,
            auto_increment_value=model.auto_increment_value,
            response_delay_bytes=model.response_delay_bytes,
        )
        self.stage_block(0x00, model.image())
        self.commit(wait=True)
        if enable:
            self.enable(True)

    # ------------------------------------------------------------------
    # Capture API (current RTL)
    # ------------------------------------------------------------------

    def capture_configure(
        self,
        *,
        triggers: Iterable[tuple[int, int]] = (),
        transaction_limit: int = 0,
        byte_limit: int = 0,
        record_limit: int = 512,
    ) -> None:
        """Configure triggered and bounded capture.

        A zero transaction or byte limit disables that limit. The triggering
        transaction counts as transaction one. Byte-limit completion waits for
        the current transaction END; record_limit is an immediate hard ceiling.
        Trigger comparison masks both the incoming byte and trigger_value, so
        mask=0xF0/value=0xA5 matches any 0xAx command.
        """
        rules = list(triggers)
        if len(rules) > 4:
            raise ValueError("at most four capture trigger rules are supported")

        encoded_rules: list[tuple[int, int]] = []
        for index, rule in enumerate(rules):
            if not isinstance(rule, (tuple, list)) or len(rule) != 2:
                raise ValueError(f"trigger rule {index} must be a (mask, value) pair")
            encoded_rules.append(
                (_u8(f"trigger[{index}] mask", rule[0]),
                 _u8(f"trigger[{index}] value", rule[1]))
            )
        limits = []
        for name, value in (
            ("transaction_limit", transaction_limit),
            ("byte_limit", byte_limit),
            ("record_limit", record_limit),
        ):
            value = int(value)
            if not 0 <= value <= 0xFFFF:
                raise ValueError(f"{name} must be 0..65535")
            limits.append(value)
        if limits[2] > 512:
            raise ValueError("record_limit cannot exceed the 512-record capture depth")

        rule_enable = (1 << len(encoded_rules)) - 1
        flags = (0x01 if encoded_rules else 0x00) | (rule_enable << 1)
        padded_rules = encoded_rules + [(0, 0)] * (4 - len(encoded_rules))
        payload = bytes((flags,)) + bytes(
            byte for rule in padded_rules for byte in rule
        ) + b"".join(
            value.to_bytes(2, "little") for value in limits
        )
        self._dev._command(
            CMD_SPI_CAPTURE_CONFIG,
            payload,
            expected_type=PACKET_TYPE_ACK,
        )

    def capture_start(self) -> None:
        self._dev._command(
            CMD_SPI_CAPTURE_START, b"", expected_type=PACKET_TYPE_ACK, retry_busy=True
        )

    def capture_stop(self) -> None:
        self._dev._command(
            CMD_SPI_CAPTURE_STOP, b"", expected_type=PACKET_TYPE_ACK, retry_busy=True
        )

    def capture_clear(self) -> None:
        self._dev._command(
            CMD_SPI_CAPTURE_CLEAR, b"", expected_type=PACKET_TYPE_ACK, retry_busy=True
        )

    def capture_status(self) -> CaptureStatus:
        packet = self._dev._command(
            CMD_SPI_CAPTURE_STATUS,
            b"",
            expected_type=PACKET_TYPE_SPI_CAPTURE_STATUS_RESP,
        )
        if len(packet.payload) not in (5, 9):
            raise self._dev.ProtocolError(
                f"capture status returned {len(packet.payload)} bytes, expected 5 or 9"
            )
        flags = packet.payload[0]
        count = packet.payload[1] | (packet.payload[2] << 8)
        depth = packet.payload[3] | (packet.payload[4] << 8)
        return CaptureStatus(
            active=bool(flags & 0x01),
            full=bool(flags & 0x02),
            empty=bool(flags & 0x04),
            loss_or_overflow=bool(flags & 0x08),
            count=count,
            depth=depth,
            armed=bool(flags & 0x20),
            triggered=bool(flags & 0x40),
            done=bool(flags & 0x80),
            transaction_count=(
                int.from_bytes(packet.payload[5:7], "little")
                if len(packet.payload) >= 9 else 0
            ),
            byte_count=(
                int.from_bytes(packet.payload[7:9], "little")
                if len(packet.payload) >= 9 else 0
            ),
        )

    def capture_read(self, index: int) -> CaptureRecord:
        index = int(index)
        if not 0 <= index <= 0xFFFF:
            raise ValueError("capture index must be 0..65535")
        payload = bytes((index & 0xFF, (index >> 8) & 0xFF, 1))
        packet = self._dev._command(
            CMD_SPI_CAPTURE_READ,
            payload,
            expected_type=PACKET_TYPE_SPI_CAPTURE_READ_RESP,
        )
        if len(packet.payload) != 9:
            raise self._dev.ProtocolError(
                f"capture record returned {len(packet.payload)} bytes, expected 9"
            )

        flags = packet.payload[0]
        return CaptureRecord(
            index=index,
            event_type=flags & 0x03,
            transaction_lost=bool(flags & 0x04),
            mosi=packet.payload[1],
            miso=packet.payload[2],
            timestamp=Timestamp(int.from_bytes(packet.payload[3:9], "little")),
        )

    def capture_records(self) -> list[CaptureRecord]:
        status = self.capture_status()
        return [self.capture_read(i) for i in range(status.count)]

    # ------------------------------------------------------------------

    def _validate_atomic_window(self, start: int, length: int) -> None:
        if not self._atomic_windows:
            return
        end = start + length
        for window_start, window_length in self._atomic_windows:
            if start >= window_start and end <= window_start + window_length:
                return
        raise ValueError(
            f"update 0x{start:02X}..0x{end - 1:02X} is outside configured atomic windows"
        )
