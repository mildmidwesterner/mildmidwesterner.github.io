"""Timestamp conversion for the 27 MHz Tang Nano HIL build."""

from __future__ import annotations

from dataclasses import dataclass


_CLOCK_HZ = 27_000_000
_TIMESTAMP_BITS = 48
_TIMESTAMP_MASK = (1 << _TIMESTAMP_BITS) - 1


@dataclass(frozen=True)
class Duration:
    """Elapsed time represented as FPGA system-clock ticks."""

    ticks: int

    def __post_init__(self) -> None:
        if self.ticks < 0:
            raise ValueError("duration ticks cannot be negative")

    @property
    def seconds(self) -> float:
        return self.ticks / _CLOCK_HZ

    @property
    def milliseconds(self) -> float:
        return self.ticks * 1_000 / _CLOCK_HZ

    @property
    def microseconds(self) -> float:
        return self.ticks * 1_000_000 / _CLOCK_HZ

    @property
    def nanoseconds(self) -> float:
        return self.ticks * 1_000_000_000 / _CLOCK_HZ


@dataclass(frozen=True)
class Timestamp:
    """A raw 48-bit FPGA timestamp with Tang Nano time conversions."""

    ticks: int

    def __post_init__(self) -> None:
        if not 0 <= self.ticks <= _TIMESTAMP_MASK:
            raise ValueError("timestamp ticks must fit in 48 bits")

    @property
    def raw_ticks(self) -> int:
        return self.ticks

    @property
    def seconds(self) -> float:
        return self.ticks / _CLOCK_HZ

    @property
    def milliseconds(self) -> float:
        return self.ticks * 1_000 / _CLOCK_HZ

    @property
    def microseconds(self) -> float:
        return self.ticks * 1_000_000 / _CLOCK_HZ

    @property
    def nanoseconds(self) -> float:
        return self.ticks * 1_000_000_000 / _CLOCK_HZ

    def __int__(self) -> int:
        return self.ticks

    def __sub__(self, earlier: "Timestamp") -> Duration:
        if not isinstance(earlier, Timestamp):
            return NotImplemented
        return Duration((self.ticks - earlier.ticks) & _TIMESTAMP_MASK)
