"""Serial packet transport for the FPGA HIL protocol."""

from __future__ import annotations

import time
from typing import Optional

import serial

from .protocol import (
    MAX_PAYLOAD_BYTES,
    SYNC0,
    SYNC1,
    Packet,
    crc16_ccitt_false,
    encode_packet,
)


class TransportError(RuntimeError):
    pass


class PacketTimeout(TransportError):
    pass


class PacketCrcError(TransportError):
    pass


class SerialTransport:
    def __init__(
        self,
        port: str,
        baudrate: int = 115200,
        *,
        timeout: float = 1.0,
    ) -> None:
        self.port = port
        self.baudrate = int(baudrate)
        self.timeout = float(timeout)
        self._serial: Optional[serial.Serial] = None

    @property
    def is_open(self) -> bool:
        return self._serial is not None and self._serial.is_open

    def open(self) -> None:
        if self.is_open:
            return

        self._serial = serial.Serial(
            port=self.port,
            baudrate=self.baudrate,
            timeout=0.05,
            write_timeout=self.timeout,
            rtscts=False,
            dsrdtr=False,
        )
        self._serial.reset_input_buffer()
        self._serial.reset_output_buffer()

    def close(self) -> None:
        if self._serial is not None:
            self._serial.close()
            self._serial = None

    def flush_input(self) -> None:
        self._require_open().reset_input_buffer()

    def write_packet(self, packet_type: int, seq: int, payload: bytes = b"") -> None:
        ser = self._require_open()
        frame = encode_packet(packet_type, seq, payload)
        written = ser.write(frame)
        if written != len(frame):
            raise TransportError(f"short serial write: {written}/{len(frame)} bytes")
        ser.flush()

    def read_packet(self, *, timeout: Optional[float] = None) -> Packet:
        ser = self._require_open()
        deadline = time.monotonic() + (self.timeout if timeout is None else float(timeout))

        # Resynchronize on A5 5A.
        saw_sync0 = False
        while True:
            byte = self._read_one_until(ser, deadline)
            if not saw_sync0:
                saw_sync0 = byte == SYNC0
                continue
            if byte == SYNC1:
                break
            saw_sync0 = byte == SYNC0

        header = self._read_exact_until(ser, 3, deadline)
        packet_type, seq, length = header
        if length > MAX_PAYLOAD_BYTES:
            raise TransportError(
                f"FPGA packet length {length} exceeds protocol maximum {MAX_PAYLOAD_BYTES}"
            )

        payload = self._read_exact_until(ser, length, deadline)
        crc_bytes = self._read_exact_until(ser, 2, deadline)
        received_crc = crc_bytes[0] | (crc_bytes[1] << 8)
        calculated_crc = crc16_ccitt_false(header + payload)

        if received_crc != calculated_crc:
            raise PacketCrcError(
                f"CRC mismatch: received 0x{received_crc:04X}, "
                f"calculated 0x{calculated_crc:04X}"
            )

        return Packet(packet_type, seq, payload)

    def _require_open(self) -> serial.Serial:
        if not self.is_open:
            raise TransportError("serial transport is not open")
        assert self._serial is not None
        return self._serial

    @staticmethod
    def _read_one_until(ser: serial.Serial, deadline: float) -> int:
        while time.monotonic() < deadline:
            data = ser.read(1)
            if data:
                return data[0]
        raise PacketTimeout("timed out waiting for FPGA packet")

    @classmethod
    def _read_exact_until(cls, ser: serial.Serial, count: int, deadline: float) -> bytes:
        data = bytearray()
        while len(data) < count:
            if time.monotonic() >= deadline:
                raise PacketTimeout(
                    f"timed out while reading packet ({len(data)}/{count} bytes)"
                )
            chunk = ser.read(count - len(data))
            if chunk:
                data.extend(chunk)
        return bytes(data)
